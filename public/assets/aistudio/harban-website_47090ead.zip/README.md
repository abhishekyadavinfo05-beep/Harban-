# HARBAN — Precision Trimmers

A React + Vite + Tailwind CSS v4 storefront for the HARBAN grooming range.

## Requirements

- Node.js 18 or newer
- npm (or pnpm / yarn)

## Setup

```bash
npm install
```

## Development

```bash
npm run dev
```

Then open the URL it prints (default <http://localhost:5173>).

## Production build

```bash
npm run build     # outputs to dist/
npm run preview   # serve the built site locally
```

Deploy the contents of `dist/` to any static host (Vercel, Netlify, Cloudflare
Pages, GitHub Pages, S3, or plain nginx).

## Project structure

```
index.html                  entry HTML (fonts, meta, favicon)
vite.config.js              Vite + React + Tailwind plugins
src/
  main.jsx                  app bootstrap
  App.jsx                   routes and page composition
  index.css                 Tailwind import + design tokens + keyframes
  data/products.js          catalogue, categories, reviews, FAQs
  store/shop.jsx            cart, orders, search, toasts, routing state
  components/
    Header.jsx              announcement bar, nav, search, cart button
    Hero.jsx                3-slide hero carousel with feature bar
    Sections.jsx            trust marquee, category icons, banners, story
    Trust.jsx               stat strip, reviews carousel
    ProductCard.jsx         product card + row layout
    ProductSlider.jsx       sliding product rail (autoplay, arrows, dots)
    ProductPage.jsx         product detail with tabs and gallery
    Drawers.jsx             cart drawer, quick view, order tracking, toasts
    Footer.jsx              FAQ, newsletter, footer
    Img.jsx                 image with remote fallback
    ui.jsx                  shared Stars / SectionHead / Pill primitives
public/
  images/                   product and banner imagery
  favicon.svg
```

## Notes

- Cart and orders persist in `localStorage` (`harban-cart`, `harban-orders`).
- Prices are formatted in Indian rupees via `Intl` (`en-IN`).
- The hero carousel supports arrows, dots, keyboard arrows, touch swipe and
  pauses while hovered; it respects `prefers-reduced-motion`.
- The "Top Rated" product rail and the reviews rail both autoplay every 3
  seconds. They pause on hover/touch, hold for 6 seconds after any manual
  interaction, and stay still when reduced motion is requested.
- Product images live in `public/images/`, so they are served from `/images/...`
  in both development and production.
- The header scrolls away with the page (it is not sticky).
