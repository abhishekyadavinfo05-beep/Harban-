import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: '127.0.0.1',
    port: 5199,
    strictPort: true,
    watch: {
      // editor temp folders can be locked mid-write and crash the watcher
      ignored: ['**/.*.tmpdir/**', '**/*.tmp'],
    },
  },
})