import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import { products } from '../data/products'

const ShopContext = createContext(null)

/* ---------------------------------------------------------------- helpers */

export const formatINR = (n) => `Rs. ${Number(n).toLocaleString('en-IN')}`

export const discountOf = (p) => Math.round(((p.mrp - p.price) / p.mrp) * 100)

export const FREE_SHIP_THRESHOLD = 1500

function readLocal(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

function writeLocal(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* storage unavailable — cart simply will not persist */
  }
}

function makeOrderId() {
  const d = new Date()
  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(
    d.getDate(),
  ).padStart(2, '0')}`
  return `HRB-${stamp}-${Math.floor(1000 + Math.random() * 9000)}`
}

export const ORDER_STAGES = [
  'Order placed',
  'Packed',
  'Shipped',
  'Out for delivery',
  'Delivered',
]

export const NAV_ITEMS = [
  { id: 'home', label: 'Home' },
  { id: 'trimmers', label: 'Trimmers' },
  { id: 'accessories', label: 'Accessories' },
  { id: 'support', label: 'Support' },
]

/* -------------------------------------------------------------- provider */

export function ShopProvider({ children }) {
  const [cart, setCart] = useState(() => readLocal('harban-cart', []))
  const [orders, setOrders] = useState(() => readLocal('harban-orders', []))
  const [cartOpen, setCartOpen] = useState(false)
  const [trackOpen, setTrackOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [quickView, setQuickView] = useState(null)
  const [toasts, setToasts] = useState([])
  const [route, setRoute] = useState('home')

  useEffect(() => writeLocal('harban-cart', cart), [cart])
  useEffect(() => writeLocal('harban-orders', orders), [orders])

  const pushToast = useCallback((message) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
    setToasts((t) => [...t, { id, message }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2600)
  }, [])

  const addToCart = useCallback(
    (product, qty = 1) => {
      setCart((c) => {
        const found = c.find((i) => i.id === product.id)
        if (found) {
          return c.map((i) =>
            i.id === product.id ? { ...i, qty: i.qty + qty } : i,
          )
        }
        return [
          ...c,
          {
            id: product.id,
            name: product.name,
            image: product.image,
            price: product.price,
            qty,
          },
        ]
      })
      pushToast(`${product.name} added to cart`)
    },
    [pushToast],
  )

  const setQty = useCallback((id, qty) => {
    setCart((c) =>
      qty <= 0
        ? c.filter((i) => i.id !== id)
        : c.map((i) => (i.id === id ? { ...i, qty } : i)),
    )
  }, [])

  const removeFromCart = useCallback(
    (id) => setCart((c) => c.filter((i) => i.id !== id)),
    [],
  )

  const clearCart = useCallback(() => setCart([]), [])

  const buyNow = useCallback(
    (product, qty = 1) => {
      addToCart(product, qty)
      setCartOpen(true)
    },
    [addToCart],
  )

  const placeOrder = useCallback(() => {
    if (!cart.length) return null
    const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0)
    const shipping = 0
    const order = {
      id: makeOrderId(),
      items: cart.map((v) => ({ ...v })),
      subtotal,
      shipping,
      total: subtotal + shipping,
      status: 1,
      placedAt: Date.now(),
      eta: Date.now() + 96 * 3600 * 1000,
    }
    setOrders((o) => [order, ...o])
    clearCart()
    setCartOpen(false)
    setRoute('order-confirmed')
    return order
  }, [cart, clearCart])

  const go = useCallback((next) => {
    setRoute(next)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [])

  const value = useMemo(() => {
    const cartCount = cart.reduce((s, i) => s + i.qty, 0)
    const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0)
    const lastOrder = orders[0] ?? null
    return {
      cart,
      cartCount,
      subtotal,
      shipping: 0,
      total: subtotal,
      addToCart,
      setQty,
      removeFromCart,
      clearCart,
      buyNow,
      placeOrder,
      orders,
      lastOrder,
      cartOpen,
      setCartOpen,
      trackOpen,
      setTrackOpen,
      search,
      setSearch,
      quickView,
      setQuickView,
      toasts,
      pushToast,
      route,
      go,
      products,
    }
  }, [
    cart,
    orders,
    addToCart,
    setQty,
    removeFromCart,
    clearCart,
    buyNow,
    placeOrder,
    cartOpen,
    trackOpen,
    search,
    quickView,
    toasts,
    pushToast,
    route,
    go,
  ])

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>
}

export function useShop() {
  const ctx = useContext(ShopContext)
  if (!ctx) throw new Error('useShop must be used inside ShopProvider')
  return ctx
}
