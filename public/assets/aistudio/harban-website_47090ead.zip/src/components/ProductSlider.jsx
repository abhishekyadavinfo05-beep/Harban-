import { useEffect, useRef, useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import ProductCard from './ProductCard'

/* Horizontal product carousel: swipe on touch, snap on every card, with
   arrow controls, dots and an autoplay that advances every few seconds.
   Used above the reviews section on the home page. */
const AUTOPLAY_MS = 3000
const RESUME_AFTER_MS = 6000

export default function ProductSlider({ products, title, sub, action }) {
  const rail = useRef(null)
  const [itemW, setItemW] = useState(0)
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const [cooldown, setCooldown] = useState(false)
  const total = products.length

  /* measure one card (plus gap) so arrows and dots can page the rail */
  useEffect(() => {
    const el = rail.current
    if (!el) return
    const measure = () => {
      const first = el.firstElementChild
      if (!first) return
      const gap = parseFloat(getComputedStyle(el).columnGap || '0') || 0
      setItemW(first.getBoundingClientRect().width + gap)
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [products.length])

  const onScroll = () => {
    const el = rail.current
    if (!el || !itemW) return
    setIndex(Math.round(el.scrollLeft / itemW))
  }

  const goTo = (i, behavior = 'smooth') => {
    const el = rail.current
    if (!el || !itemW) return
    const next = Math.max(0, Math.min(i, total - 1))
    el.scrollTo({ left: next * itemW, behavior })
  }

  /* autoplay: step forward every 3s, wrapping back to the first card at the
     end. Pauses while hovered and for a short cooldown after any manual
     interaction, and is skipped entirely when reduced motion is requested. */
  useEffect(() => {
    const reduce = window.matchMedia?.(
      '(prefers-reduced-motion: reduce)',
    ).matches
    if (paused || cooldown || reduce || !itemW || total < 2) return

    const t = setInterval(() => {
      setIndex((i) => {
        const next = i >= total - 1 ? 0 : i + 1
        const el = rail.current
        if (el) el.scrollTo({ left: next * itemW, behavior: 'smooth' })
        return next
      })
    }, AUTOPLAY_MS)

    return () => clearInterval(t)
  }, [paused, cooldown, itemW, total])

  /* briefly hold autoplay after a manual interaction so it does not fight
     the visitor for control of the rail */
  const holdAutoplay = () => {
    setCooldown(true)
    window.setTimeout(() => setCooldown(false), RESUME_AFTER_MS)
  }

  return (
    <section className="max-w-7xl mx-auto px-4 mt-10">
      <div className="flex items-end justify-between gap-4 mb-3">
        <div>
          <h2 className="font-display font-extrabold text-[20px] sm:text-[24px] tracking-tight">
            {title}
          </h2>
          {sub && <p className="text-[13px] text-neutral-500 mt-0.5">{sub}</p>}
        </div>

        <div className="flex items-center gap-3 shrink-0">
          {action}
          <div className="hidden sm:flex items-center gap-2">
            <button
              onClick={() => {
                holdAutoplay()
                goTo(index - 1)
              }}
              disabled={index === 0}
              aria-label="Previous products"
              className="grid place-items-center w-9 h-9 rounded-full bg-white border border-black/10 hover:border-[#1D5CAD] hover:text-[#1D5CAD] disabled:opacity-35 disabled:hover:border-black/10 disabled:hover:text-inherit transition"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={() => {
                holdAutoplay()
                goTo(index + 1)
              }}
              disabled={index >= total - 1}
              aria-label="Next products"
              className="grid place-items-center w-9 h-9 rounded-full bg-white border border-black/10 hover:border-[#1D5CAD] hover:text-[#1D5CAD] disabled:opacity-35 disabled:hover:border-black/10 disabled:hover:text-inherit transition"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>

      {/* rail — compact cards so five fit across on wide screens */}
      <div
        ref={rail}
        onScroll={onScroll}
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
        onTouchStart={() => setPaused(true)}
        onTouchEnd={() => {
          holdAutoplay()
          setPaused(false)
        }}
        className="flex items-stretch gap-2.5 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-1"
      >
        {products.map((p) => (
          <div
            key={p.id}
            className="snap-start shrink-0 flex w-[48%] sm:w-[calc((100%-1.25rem)/3)] lg:w-[calc((100%-2.5rem)/5)]"
          >
            <ProductCard product={p} />
          </div>
        ))}
      </div>

      {/* dots */}
      <div className="flex justify-center gap-1.5 mt-3">
        {products.map((p, i) => (
          <button
            key={p.id}
            onClick={() => {
              holdAutoplay()
              goTo(i)
            }}
            aria-label={`Go to product ${i + 1}`}
            aria-current={i === index || undefined}
            className={`h-[6px] rounded-full transition-all ${
              i === index
                ? 'w-6 bg-[#1D5CAD]'
                : 'w-[6px] bg-neutral-300 hover:bg-neutral-400'
            }`}
          />
        ))}
      </div>
    </section>
  )
}
