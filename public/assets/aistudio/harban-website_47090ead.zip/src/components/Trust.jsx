import { useEffect, useRef, useState } from 'react'
import { BadgeCheck, ChevronLeft, ChevronRight } from 'lucide-react'
import { SectionHead, Stars } from './ui'
import { marqueeStats, testimonials } from '../data/products'

/* ----------------------------------------------- scrolling stat strip */

export function TrustMarquee() {
  const Track = ({ hidden = false }) => (
    <div
      className="flex items-center gap-8 animate-marquee shrink-0"
      aria-hidden={hidden || undefined}
    >
      {marqueeStats.map(([value, label]) => (
        <div key={label} className="text-center px-1 leading-tight">
          <p className="font-display font-black text-[17px] text-[#E8C547] leading-none">
            {value}
          </p>
          <p className="text-[11px] text-white/60 font-semibold whitespace-nowrap mt-0.5">
            {label}
          </p>
        </div>
      ))}
    </div>
  )

  return (
    <section className="bg-[#0C1B2E] text-white overflow-hidden mt-8">
      <div className="max-w-7xl mx-auto px-4 py-3 flex gap-8 overflow-hidden marquee-wrap">
        <Track />
        <Track hidden />
      </div>
    </section>
  )
}

/* ------------------------------------------------------------ reviews */

const AUTOPLAY_MS = 3000
const RESUME_AFTER_MS = 6000

export function Reviews() {
  const rail = useRef(null)
  const [itemW, setItemW] = useState(0)
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const [cooldown, setCooldown] = useState(false)
  const total = testimonials.length

  /* measure one card (plus gap) so arrows and dots can page through the rail */
  useEffect(() => {
    const el = rail.current
    if (!el) return
    const measure = () => {
      const first = el.firstElementChild
      if (!first) return
      const gap = parseFloat(getComputedStyle(el).columnGap || '0') || 0
      setItemW(first.getBoundingClientRect().width + gap)
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [])

  const onScroll = () => {
    const el = rail.current
    if (!el || !itemW) return
    setIndex(Math.round(el.scrollLeft / itemW))
  }

  const goTo = (i) => {
    const el = rail.current
    if (!el || !itemW) return
    const next = Math.max(0, Math.min(i, total - 1))
    el.scrollTo({ left: next * itemW, behavior: 'smooth' })
  }

  /* autoplay: advance every 3s, wrapping to the first review at the end.
     Pauses on hover/touch and for a cooldown after manual interaction, and
     stays off when reduced motion is requested. */
  useEffect(() => {
    const reduce = window.matchMedia?.(
      '(prefers-reduced-motion: reduce)',
    ).matches
    if (paused || cooldown || reduce || !itemW || total < 2) return

    const t = setInterval(() => {
      setIndex((i) => {
        const next = i >= total - 1 ? 0 : i + 1
        const el = rail.current
        if (el) el.scrollTo({ left: next * itemW, behavior: 'smooth' })
        return next
      })
    }, AUTOPLAY_MS)

    return () => clearInterval(t)
  }, [paused, cooldown, itemW, total])

  const holdAutoplay = () => {
    setCooldown(true)
    window.setTimeout(() => setCooldown(false), RESUME_AFTER_MS)
  }

  return (
    <section className="max-w-7xl mx-auto px-4 mt-10">
      <SectionHead
        title="Loved Across India"
        sub="4.7 average from 3,700+ verified reviews."
        action={
          <div className="hidden sm:flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                holdAutoplay()
                goTo(index - 1)
              }}
              disabled={index === 0}
              aria-label="Previous reviews"
              className="grid place-items-center w-9 h-9 rounded-full bg-white border border-black/10 hover:border-[#1D5CAD] hover:text-[#1D5CAD] disabled:opacity-35 disabled:hover:border-black/10 disabled:hover:text-inherit transition"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={() => {
                holdAutoplay()
                goTo(index + 1)
              }}
              disabled={index >= total - 1}
              aria-label="Next reviews"
              className="grid place-items-center w-9 h-9 rounded-full bg-white border border-black/10 hover:border-[#1D5CAD] hover:text-[#1D5CAD] disabled:opacity-35 disabled:hover:border-black/10 disabled:hover:text-inherit transition"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        }
      />

      {/* rail — swipe on touch, snap on every card, autoplays every 3s */}
      <div
        ref={rail}
        onScroll={onScroll}
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
        onTouchStart={() => setPaused(true)}
        onTouchEnd={() => {
          holdAutoplay()
          setPaused(false)
        }}
        className="flex items-stretch gap-3 sm:gap-4 overflow-x-auto no-scrollbar snap-x snap-mandatory pb-1"
      >
        {testimonials.map((r) => (
          <div
            key={r.n}
            className="snap-start shrink-0 flex w-[85%] sm:w-[calc((100%-1rem)/2)] lg:w-[calc((100%-2rem)/3)]"
          >
            <div className="w-full bg-white rounded-2xl p-5 border border-black/5 flex flex-col">
            <Stars rating={5} size={14} />
            <p className="text-[13.5px] text-neutral-700 leading-relaxed mt-2.5">
              &ldquo;{r.t}&rdquo;
            </p>
            <p className="text-[12.5px] font-bold mt-auto pt-3">
              {r.n}{' '}
              <span className="font-normal text-neutral-400">· {r.c}</span>
            </p>
            <p className="text-[11.5px] font-bold text-[#174A8B] flex items-center gap-1 mt-0.5">
              <BadgeCheck size={13} /> Verified buyer · {r.p}
            </p>
            </div>
          </div>
        ))}
      </div>

      {/* dots */}
      <div className="flex justify-center gap-1.5 mt-3">
        {testimonials.map((r, i) => (
          <button
            key={r.n}
            onClick={() => {
              holdAutoplay()
              goTo(i)
            }}
            aria-label={`Go to review ${i + 1}`}
            aria-current={i === index || undefined}
            className={`h-[6px] rounded-full transition-all ${
              i === index
                ? 'w-6 bg-[#1D5CAD]'
                : 'w-[6px] bg-neutral-300 hover:bg-neutral-400'
            }`}
          />
        ))}
      </div>
    </section>
  )
}
