import { useState } from 'react'
import { Check, Minus, Plus, ShieldCheck, ShoppingCart, Truck, Undo2 } from 'lucide-react'
import Img from './Img'
import { Stars } from './ui'
import { FrequentlyAdded, ProductCard } from './Drawers'
import { discountOf, formatINR, useShop } from '../store/shop'
import { products } from '../data/products'

export default function ProductPage({ product }) {
  const { addToCart, buyNow, go } = useShop()
  const [active, setActive] = useState(0)
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState('features')

  const off = discountOf(product)
  const related = products
    .filter((p) => p.id !== product.id && p.category === product.category)
    .slice(0, 4)

  const perks = [
    { icon: Truck, label: 'Free shipping' },
    { icon: ShieldCheck, label: '1-year warranty' },
    { icon: Undo2, label: '7-day returns' },
  ]

  return (
    <>
      <section className="max-w-7xl mx-auto px-4 py-6">
        <button
          onClick={() => go('trimmers')}
          className="text-[12.5px] font-semibold text-neutral-500 hover:text-[#1D5CAD] transition"
        >
          ← Back to all trimmers
        </button>

        <div className="grid lg:grid-cols-2 gap-6 mt-4">
          {/* gallery */}
          <div>
            <div className="rounded-2xl overflow-hidden bg-white border border-black/5">
              <Img
                src={product.images[active]}
                alt={product.name}
                className="w-full h-[320px] sm:h-[420px] object-cover"
              />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-2.5 mt-3 overflow-x-auto no-scrollbar">
                {product.images.map((src, i) => (
                  <button
                    key={src}
                    onClick={() => setActive(i)}
                    className={`shrink-0 rounded-xl overflow-hidden border-2 transition ${
                      active === i ? 'border-[#1D5CAD]' : 'border-transparent'
                    }`}
                  >
                    <Img
                      src={src}
                      alt={`${product.name} view ${i + 1}`}
                      className="w-[68px] h-[68px] object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* buy box */}
          <div>
            <div className="flex items-center gap-2">
              {product.badge && (
                <span className="bg-[#0C1B2E] text-white text-[10.5px] font-bold uppercase tracking-wider rounded-full px-2.5 py-1">
                  {product.badge}
                </span>
              )}
              {off > 0 && (
                <span className="bg-[#E8C547] text-[#0C1B2E] text-[10.5px] font-black uppercase tracking-wider rounded-full px-2.5 py-1">
                  {off}% off
                </span>
              )}
            </div>

            <h1 className="font-display font-black text-[28px] sm:text-[34px] leading-tight mt-2.5">
              {product.name}
            </h1>
            <p className="text-[13.5px] text-neutral-500 mt-1">
              {product.tagline}
            </p>

            <div className="flex items-center gap-2 mt-3">
              <Stars rating={product.rating} size={15} />
              <span className="text-[12.5px] font-semibold text-neutral-500">
                {product.rating} · {product.reviews.toLocaleString('en-IN')}{' '}
                verified reviews
              </span>
            </div>

            <div className="flex items-baseline gap-3 mt-4">
              <span className="font-display font-black text-[30px]">
                {formatINR(product.price)}
              </span>
              <span className="text-[16px] text-neutral-400 line-through">
                {formatINR(product.mrp)}
              </span>
              {off > 0 && (
                <span className="text-[13px] font-bold text-emerald-600">
                  Save {formatINR(product.mrp - product.price)}
                </span>
              )}
            </div>
            <p className="text-[11.5px] text-neutral-500 mt-1">
              Inclusive of all taxes
            </p>

            <p className="text-[13.5px] text-neutral-600 leading-relaxed mt-4">
              {product.description}
            </p>

            <div className="flex items-center gap-3 mt-6">
              <div className="inline-flex items-center gap-1 bg-white rounded-full border border-black/10 px-2 py-1.5">
                <button
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="grid place-items-center w-8 h-8 rounded-full hover:bg-neutral-100"
                  aria-label="Decrease quantity"
                >
                  <Minus size={14} />
                </button>
                <span className="font-bold w-7 text-center">{qty}</span>
                <button
                  onClick={() => setQty(qty + 1)}
                  className="grid place-items-center w-8 h-8 rounded-full hover:bg-neutral-100"
                  aria-label="Increase quantity"
                >
                  <Plus size={14} />
                </button>
              </div>

              <button
                onClick={() => addToCart(product, qty)}
                className="flex-1 inline-flex items-center justify-center gap-2 bg-[#0C1B2E] hover:bg-[#1D5CAD] text-white text-[14px] font-bold py-3.5 rounded-xl transition"
              >
                <ShoppingCart size={17} /> Add to Cart
              </button>
            </div>

            <button
              onClick={() => buyNow(product, qty)}
              className="mt-2.5 w-full bg-[#1D5CAD] hover:bg-[#16467E] text-white text-[14px] font-bold py-3.5 rounded-xl transition"
            >
              Buy Now
            </button>

            <div className="grid grid-cols-3 gap-2.5 mt-5">
              {perks.map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  className="flex items-center gap-2 bg-white rounded-xl border border-black/5 px-3 py-2.5"
                >
                  <Icon size={16} className="text-[#1D5CAD] shrink-0" />
                  <span className="text-[11.5px] font-bold leading-tight">
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* details tabs */}
      <section className="max-w-7xl mx-auto px-4 mt-4">
        <div className="bg-white rounded-2xl border border-black/5 overflow-hidden">
          <div className="flex border-b border-black/5 overflow-x-auto no-scrollbar">
            {[
              ['features', 'Features'],
              ['specs', 'Specifications'],
              ['box', 'In the box'],
            ].map(([id, label]) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`px-5 py-3.5 text-[13px] font-bold whitespace-nowrap transition border-b-2 -mb-px ${
                  tab === id
                    ? 'border-[#1D5CAD] text-[#1D5CAD]'
                    : 'border-transparent text-neutral-500 hover:text-neutral-800'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="p-5">
            {tab === 'features' && (
              <ul className="grid sm:grid-cols-2 gap-2.5">
                {product.features.map((f) => (
                  <li key={f} className="text-[13px] text-neutral-700 flex gap-2">
                    <Check size={15} className="text-[#1D5CAD] shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
            )}

            {tab === 'specs' && (
              <dl className="grid sm:grid-cols-2 gap-x-8">
                {product.specs.map((s) => (
                  <div
                    key={s.label}
                    className="flex justify-between gap-4 py-2.5 border-b border-black/5 text-[13px]"
                  >
                    <dt className="text-neutral-500 font-semibold">{s.label}</dt>
                    <dd className="font-semibold text-right">{s.value}</dd>
                  </div>
                ))}
              </dl>
            )}

            {tab === 'box' && (
              <p className="text-[13px] text-neutral-600 leading-relaxed">
                {product.specs.find((s) => s.label === 'In the box')?.value ??
                  'See the specifications tab for full contents.'}
              </p>
            )}
          </div>
        </div>
      </section>

      <FrequentlyAdded current={product} />

      {related.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 mt-10">
          <h2 className="font-display font-extrabold text-[20px] sm:text-[24px] tracking-tight mb-4">
            You may also like
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </>
  )
}
