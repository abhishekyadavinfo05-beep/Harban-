import { useState } from 'react'
import {
  ArrowRight,
  Facebook,
  Instagram,
  Mail,
  MapPin,
  Phone,
  Plus,
  Twitter,
  Youtube,
} from 'lucide-react'
import { faqs } from '../data/products'
import { useShop } from '../store/shop'

/* ------------------------------------------------------------------ FAQ */

export function Faq() {
  const [open, setOpen] = useState(0)

  return (
    <section className="max-w-7xl mx-auto px-4 mt-10">
      <h2 className="font-display font-extrabold text-[20px] sm:text-[24px] tracking-tight mb-3">
        Frequently asked questions
      </h2>

      <div className="space-y-2">
        {faqs.map((f, i) => (
          <div
            key={f.q}
            className={`bg-white rounded-xl border overflow-hidden transition ${
              open === i ? 'border-[#1D5CAD]/60' : 'border-black/5'
            }`}
          >
            <button
              onClick={() => setOpen(open === i ? -1 : i)}
              className="w-full flex items-center justify-between gap-3 text-left px-5 py-4 font-bold text-[14px]"
            >
              {f.q}
              <span
                className={`w-7 h-7 rounded-full grid place-items-center shrink-0 transition ${
                  open === i
                    ? 'bg-[#1D5CAD] text-white rotate-45'
                    : 'bg-neutral-100'
                }`}
              >
                <Plus size={15} />
              </span>
            </button>
            {open === i && (
              <p className="px-5 pb-4 text-[13.5px] text-neutral-600 leading-relaxed animate-fade-up">
                {f.a}
              </p>
            )}
          </div>
        ))}
      </div>

      <div className="bg-[#0C1B2E] text-white rounded-2xl p-6 sm:p-7 mt-8">
        <div className="grid md:grid-cols-[1fr_auto] gap-6 md:items-center">
          <div>
            <h3 className="font-display font-extrabold text-lg">
              Help &amp; Support
            </h3>
            <div className="flex flex-wrap gap-x-8 gap-y-2.5 mt-4 text-[13.5px]">
              <p className="flex items-center gap-2.5 text-white/80">
                <Phone size={15} className="text-[#E8C547]" /> +91 98765 43210
              </p>
              <p className="flex items-center gap-2.5 text-white/80">
                <Mail size={15} className="text-[#E8C547]" /> care@harban.in
              </p>
              <p className="flex items-center gap-2.5 text-white/80">
                <MapPin size={15} className="text-[#E8C547]" /> Mumbai, India
              </p>
            </div>
            <p className="text-white/55 text-[12.5px] leading-relaxed mt-3">
              Mon–Sat, 10am–7pm IST. Live chat and WhatsApp support available.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
              <span
                key={i}
                className="grid place-items-center w-10 h-10 rounded-full bg-white/10 hover:bg-[#1D5CAD] transition cursor-pointer"
              >
                <Icon size={17} />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ------------------------------------------------------------ newsletter */

export function Newsletter() {
  const [email, setEmail] = useState('')
  const { pushToast } = useShop()

  const submit = (e) => {
    e.preventDefault()
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      pushToast('Enter a valid email to subscribe')
      return
    }
    pushToast('Subscribed! Grooming tips incoming.')
    setEmail('')
  }

  return (
    <section className="max-w-7xl mx-auto px-4 mt-10">
      <div className="bg-[#1D5CAD] rounded-2xl px-5 py-7 sm:px-9 sm:py-8 grid md:grid-cols-[1.1fr_1fr] gap-5 sm:gap-6 items-center">
        <div>
          <h3 className="font-display font-black text-white text-[20px] sm:text-[26px] leading-tight">
            Subscribe to Our Newsletter
          </h3>
          <p className="text-white/75 text-[13px] sm:text-[13.5px] mt-1.5 leading-snug">
            Get the latest updates, offers and grooming tips.
          </p>
        </div>

        <form
          onSubmit={submit}
          className="flex items-center gap-2 w-full max-w-[420px] md:max-w-none md:ml-auto"
        >
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            aria-label="Email address"
            className="flex-1 min-w-0 bg-white/95 rounded-full px-3.5 py-2.5 sm:px-4 sm:py-3 text-[13px] sm:text-sm outline-none placeholder:text-neutral-400 focus:ring-2 focus:ring-white/60"
          />
          <button
            type="submit"
            className="shrink-0 bg-[#0C1B2E] hover:bg-black text-white text-[12.5px] sm:text-[13px] font-bold px-4 sm:px-6 py-2.5 sm:py-3 rounded-full transition inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            Subscribe <ArrowRight size={15} className="shrink-0" />
          </button>
        </form>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- footer */

export function Footer() {
  const { go, setTrackOpen } = useShop()

  const columns = [
    {
      title: 'Shop',
      links: [
        ['Beard Trimmers', 'trimmers'],
        ['Body Trimmers', 'trimmers'],
        ['Nose & Ear', 'trimmers'],
        ['Accessories & Care', 'accessories'],
      ],
    },
    {
      title: 'Quick Links',
      links: [
        ['My Order', 'track'],
        ['Help & Support', 'support'],
        ['Contact Us', 'support'],
      ],
    },
  ]

  const policies = [
    'Shipping Policy',
    'Return & Refund Policy',
    'Privacy Policy',
    'Terms & Conditions',
  ]

  return (
    <footer className="bg-[#0C1B2E] text-white mt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 grid gap-5 md:grid-cols-[1.5fr_1fr_1fr]">
        <div>
          <p className="font-display font-black text-[18px] tracking-[0.18em]">
            HARBAN
          </p>
          <p className="text-[11.5px] text-white/60 leading-snug mt-1.5 max-w-xs">
            Modern grooming essentials for men who value style and precision.
          </p>
          <p className="text-[11.5px] text-white/55 leading-snug mt-2 max-w-xs">
            Designed in-house in India and tested for daily use, with free
            shipping and 7-day easy returns on every order.
          </p>
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <p className="font-bold text-[12.5px] mb-1.5">{col.title}</p>
            {/* two links per row so the whole column stays short */}
            <ul className="grid grid-cols-2 gap-x-4 gap-y-1">
              {col.links.map(([label, target]) => (
                <li key={label}>
                  <button
                    onClick={() =>
                      target === 'track' ? setTrackOpen(true) : go(target)
                    }
                    className="text-[11.5px] text-white/60 hover:text-white transition text-left"
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-[11px] text-white/50">
            © {new Date().getFullYear()} Harban. All rights reserved.
          </p>

          {/* accepted payment methods */}
          <div className="flex flex-wrap items-center justify-center gap-1">
            {['UPI', 'Visa', 'Mastercard', 'RuPay', 'COD'].map((m) => (
              <span
                key={m}
                className="text-[10px] font-bold bg-white/10 rounded px-1.5 py-0.5 text-white/70"
              >
                {m}
              </span>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1">
            {policies.map((p) => (
              <button
                key={p}
                onClick={() => go('support')}
                className="text-[10.5px] text-white/50 hover:text-white transition"
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}

/* --------------------------------------------------- generic page shell */

export function PageHeader({ title, sub }) {
  return (
    <section className="bg-[#0C1B2E] text-white">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:py-10">
        <h1 className="font-display font-black text-[26px] sm:text-[34px] tracking-tight">
          {title}
        </h1>
        {sub && <p className="text-white/65 text-[13.5px] mt-1.5">{sub}</p>}
      </div>
    </section>
  )
}
