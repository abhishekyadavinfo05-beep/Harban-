import { useCallback, useEffect, useRef, useState } from 'react'
import {
  BatteryCharging,
  ChevronLeft,
  ChevronRight,
  Scissors,
  ShieldCheck,
  Usb,
} from 'lucide-react'
import { useShop } from '../store/shop'

/* Slides mirror the original build: eyebrow, two-line headline, sub copy,
   full-bleed image, and a rotated side note on wide screens. */
const SLIDES = [
  {
    eyebrowA: 'HARBAN',
    eyebrowB: 'TRIMMERS',
    titleA: 'Precision',
    titleB: 'In Your Hands',
    sub: 'Sharp Performance. Stylish Look.',
    sub2: 'Groom Better. Everyday.',
    img: '/images/hero-trimmer.jpg',
    sideNote: 'MORE\nTHAN JUST\nA TRIMMER',
  },
  {
    eyebrowA: 'HARBAN',
    eyebrowB: 'ELITE SERIES',
    titleA: 'Built For',
    titleB: 'Modern Men',
    sub: 'Titanium blades. 150-min runtime.',
    sub2: 'Style. Control. Confidence.',
    img: '/images/banner-modern.jpg',
    sideNote: 'FLAGSHIP\nPOWER\nAT HOME',
  },
  {
    eyebrowA: 'HARBAN',
    eyebrowB: 'BODY RANGE',
    titleA: 'Your Style,',
    titleB: 'Our Priority',
    sub: 'Trim. Define. Stand Out.',
    sub2: 'SkinSafe tech, shower-safe build.',
    img: '/images/banner-style.jpg',
    sideNote: 'TRIM.\nDEFINE.\nSTAND OUT.',
  },
]

const FEATURES = [
  { icon: Scissors, label: 'Precision Blades' },
  { icon: BatteryCharging, label: 'Long Battery Life' },
  { icon: ShieldCheck, label: 'Skin Friendly' },
  { icon: Usb, label: 'USB Charging' },
]

const AUTOPLAY_MS = 6000

export default function Hero() {
  const { go } = useShop()
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)
  const touchStart = useRef(null)

  const slide = SLIDES[index]
  const total = SLIDES.length

  const next = useCallback(() => setIndex((i) => (i + 1) % total), [total])
  const prev = useCallback(
    () => setIndex((i) => (i - 1 + total) % total),
    [total],
  )

  /* auto-advance, paused while the pointer rests on the hero */
  useEffect(() => {
    if (paused) return
    const reduce = window.matchMedia?.(
      '(prefers-reduced-motion: reduce)',
    ).matches
    if (reduce) return
    const t = setInterval(next, AUTOPLAY_MS)
    return () => clearInterval(t)
  }, [next, paused])

  /* keyboard support for the carousel */
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'ArrowRight') next()
      if (e.key === 'ArrowLeft') prev()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [next, prev])

  /* touch swipe */
  const onTouchStart = (e) => {
    touchStart.current = e.touches[0].clientX
  }
  const onTouchEnd = (e) => {
    if (touchStart.current == null) return
    const dx = e.changedTouches[0].clientX - touchStart.current
    if (Math.abs(dx) > 45) (dx < 0 ? next : prev)()
    touchStart.current = null
  }

  return (
    <section
      className="relative overflow-hidden bg-[#060D1A] text-white flex flex-col aspect-[4/3] sm:aspect-video"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      aria-roledescription="carousel"
      aria-label="HARBAN highlights"
    >
      {/* background image + cinematic overlay */}
      <div className="absolute inset-0">
        {SLIDES.map((s, i) => (
          <img
            key={s.img}
            src={s.img}
            alt=""
            aria-hidden={i !== index || undefined}
            className={`absolute inset-0 w-full h-full object-cover object-center transition-opacity duration-700 ${
              i === index ? 'opacity-100' : 'opacity-0'
            }`}
          />
        ))}
        <div className="absolute inset-0 hero-glow" />
      </div>

      {/* arrows */}
      <button
        onClick={prev}
        aria-label="Previous slide"
        className="absolute left-2 sm:left-4 top-1/3 sm:top-1/2 -translate-y-1/2 z-20 w-9 h-9 grid place-items-center rounded-full bg-white/10 hover:bg-white/25 backdrop-blur transition"
      >
        <ChevronLeft size={20} />
      </button>
      <button
        onClick={next}
        aria-label="Next slide"
        className="absolute right-2 sm:right-4 top-1/3 sm:top-1/2 -translate-y-1/2 z-20 w-9 h-9 grid place-items-center rounded-full bg-white/10 hover:bg-white/25 backdrop-blur transition"
      >
        <ChevronRight size={20} />
      </button>

      {/* slide copy */}
      <div className="relative z-[5] w-full max-w-7xl mx-auto px-5 sm:px-10 pt-7 sm:pt-14 pb-14 sm:pb-20 flex-1 min-h-0 flex flex-col justify-center">
        <div key={index} className="animate-fade-up">
          <p className="text-[10px] sm:text-sm tracking-[0.28em] font-semibold text-white/85">
            {slide.eyebrowA}{' '}
            <span className="text-[#E8C547]">{slide.eyebrowB}</span>
          </p>

          <h1 className="font-display font-black leading-[1] sm:leading-[0.95] mt-2 sm:mt-3 text-[25px] sm:text-[58px] lg:text-[70px] text-balance">
            {slide.titleA}
            <br />
            {slide.titleB}
          </h1>

          <p className="mt-2 sm:mt-4 text-white/85 text-[12px] sm:text-lg leading-relaxed sm:leading-snug max-w-md">
            {slide.sub}
            <br />
            {slide.sub2}
          </p>

          <div className="mt-4 sm:mt-6">
            <button
              onClick={() => go('trimmers')}
              className="inline-flex items-center gap-2 bg-[#1D5CAD] hover:bg-[#16467E] transition text-white font-bold text-[12.5px] sm:text-[15px] px-5 sm:px-7 py-2.5 sm:py-3 rounded-full shadow-lg shadow-blue-950/40"
            >
              Shop Now <ChevronRight size={15} className="sm:hidden" />
              <ChevronRight size={17} className="hidden sm:block" />
            </button>
          </div>
        </div>

        {/* rotated side note, wide screens only */}
        <div className="hidden md:block absolute right-10 lg:right-24 top-1/2 -translate-y-1/2 text-right -rotate-[4deg]">
          <p
            key={`note-${index}`}
            className="font-display italic font-bold text-2xl lg:text-3xl leading-tight text-white/90 whitespace-pre-line drop-shadow animate-fade-up"
          >
            {slide.sideNote}
          </p>
          <span className="block mt-2 ml-auto w-24 h-[3px] bg-[#1D5CAD] rounded-full" />
        </div>
      </div>

      {/* dots — sit just above the feature bar */}
      <div className="absolute bottom-[84px] sm:bottom-[70px] left-0 right-0 z-[6] flex justify-center gap-1.5">
        {SLIDES.map((s, i) => (
          <button
            key={s.img}
            onClick={() => setIndex(i)}
            aria-label={`Go to slide ${i + 1}`}
            aria-current={i === index || undefined}
            className={`h-[6px] rounded-full transition-all ${
              i === index
                ? 'w-6 bg-[#1D5CAD]'
                : 'w-[6px] bg-white/40 hover:bg-white/70'
            }`}
          />
        ))}
      </div>

      {/* feature bar */}
      <div className="relative z-[5] border-t border-white/10 bg-black/45 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-5 sm:px-6 py-3 grid grid-cols-2 md:grid-cols-4 gap-2.5 sm:gap-3 text-[11.5px] sm:text-[13px] font-medium text-white/85">
          {FEATURES.map(({ icon: Icon, label }) => (
            <span key={label} className="flex items-center gap-2">
              <Icon size={16} className="text-white shrink-0" />
              <span className="truncate">{label}</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
