import Header from './components/Header'
import Hero from './components/Hero'
import { Banners, CategoryTiles, Story, TrustBar } from './components/Sections'
import { Reviews, TrustMarquee } from './components/Trust'
import { Faq, Footer, Newsletter, PageHeader } from './components/Footer'
import {
  CartDrawer,
  OrderConfirmed,
  QuickView,
  ShopPage,
  Toasts,
  TrackOrder,
} from './components/Drawers'
import ProductPage from './components/ProductPage'
import ProductSlider from './components/ProductSlider'
import { ProductRow } from './components/ProductCard'
import { useShop } from './store/shop'
import { products } from './data/products'

function HomePage() {
  const { go } = useShop()
  /* the six best-reviewed trimmers and groomers */
  const bestsellers = [...products]
    .filter((p) => p.category !== 'accessories')
    .sort((a, b) => b.reviews - a.reviews)
    .slice(0, 6)

  /* second product rail, shown above the reviews */
  const topRated = [...products]
    .filter((p) => p.category !== 'accessories')
    .sort((a, b) => b.rating - a.rating || b.reviews - a.reviews)

  return (
    <>
      <Hero />
      <TrustBar />

      <CategoryTiles />

      <section className="max-w-7xl mx-auto px-4 mt-4">
        <div className="flex items-end justify-between gap-4 mb-3">
          <div>
            <h2 className="font-display font-extrabold text-[20px] sm:text-[24px] tracking-tight">
              Most Popular
            </h2>
            <p className="text-[13px] text-neutral-500 mt-0.5">
              The trimmers India keeps reordering.
            </p>
          </div>
          <button
            onClick={() => go('trimmers')}
            className="hidden sm:inline-flex items-center gap-1.5 text-[13px] font-bold text-[#1D5CAD] hover:gap-2.5 transition-all"
          >
            View All Trimmers →
          </button>
        </div>
        <ProductRow products={bestsellers} columns={6} />
        <button
          onClick={() => go('trimmers')}
          className="sm:hidden mt-4 w-full py-3 rounded-xl bg-[#0C1B2E] text-white text-sm font-bold"
        >
          View All Trimmers
        </button>
      </section>

      <Banners />

      {/* sliding product rail, directly above the reviews */}
      <ProductSlider
        products={topRated}
        title="Top Rated"
        sub="Highest rated by verified buyers."
        action={
          <button
            onClick={() => go('trimmers')}
            className="hidden sm:inline-flex items-center gap-1.5 text-[13px] font-bold text-[#1D5CAD] hover:gap-2.5 transition-all"
          >
            View All Trimmers →
          </button>
        }
      />

      <Reviews />
      <Faq />
      <Newsletter />
    </>
  )
}

function SupportPage() {
  return (
    <>
      <PageHeader
        title="Help & Support"
        sub="Answers, warranty and everything after the sale."
      />
      <Faq />
    </>
  )
}

function StoryPage() {
  return (
    <>
      <PageHeader
        title="Our Story"
        sub="Built for modern men who value style, confidence and precision."
      />
      <Story />
      <Reviews />
      <Newsletter />
    </>
  )
}

export default function App() {
  const { route, quickView } = useShop()

  let page
  if (route === 'trimmers') {
    page = (
      <>
        <PageHeader
          title="Trimmers & Groomers"
          sub="Salon-grade precision for every routine."
        />
        <ShopPage />
      </>
    )
  } else if (route === 'accessories') {
    page = (
      <>
        <PageHeader
          title="Accessories & Care"
          sub="Blades, kits and combs that keep the cut fresh."
        />
        <ShopPage preset="accessories" />
      </>
    )
  } else if (route === 'story') {
    page = <StoryPage />
  } else if (route === 'support') {
    page = <SupportPage />
  } else if (route === 'order-confirmed') {
    page = <OrderConfirmed />
  } else if (route?.startsWith('product:')) {
    const id = route.slice('product:'.length)
    const product = products.find((p) => p.id === id)
    page = product ? (
      <ProductPage product={product} />
    ) : (
      <PageHeader title="Product not found" />
    )
  } else if (route && route !== 'home' && products.some((p) => p.category === route)) {
    // a category id was passed as a route
    page = (
      <>
        <PageHeader title="Shop Trimmers" sub="Filtered by category." />
        <ShopPage preset={route} />
      </>
    )
  } else {
    page = <HomePage />
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f6f7f9]">
      <Header />
      <main className="flex-1">{page}</main>
      <TrustMarquee />
      <Footer />

      <CartDrawer />
      {quickView && <QuickView />}
      <TrackOrder />
      <Toasts />
    </div>
  )
}
